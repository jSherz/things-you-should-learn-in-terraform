const {S3Client, ListObjectsCommand} = require("@aws-sdk/client-s3");

exports.handler = async (event) => {
    const client = new S3Client({});

    // Do a very naive bucket list that does not handle pagination
    const input = {
        Bucket: process.env.BUCKET,
    };
    const command = new ListObjectsCommand(input);
    const avatars = await client.send(command);

    const response = {
        statusCode: 200,
        body: JSON.stringify(avatars.Contents, null, 2),
    };
    return response;
};
